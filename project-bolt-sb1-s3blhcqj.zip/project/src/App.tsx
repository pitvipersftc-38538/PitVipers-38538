import { FormEvent, useState } from 'react';
import {
  ArrowUpRight,
  ChevronDown,
  Instagram,
  Linkedin,
  Mail,
  Menu,
  MoveRight,
  Printer,
  Radio,
  Send,
  Sparkles,
  Trophy,
  Users,
  X,
  Youtube,
} from 'lucide-react';

type RosterMember = {
  name: string;
  role?: string;
  lead?: boolean;
  photo: string;
};

const roster: RosterMember[] = [
  // Replace the URLs below with your own photo links (e.g. Google Drive share links, Imgur, etc.)
  { name: 'Advik B', role: 'Team Mentor', lead: true, photo: '/images/meet-our-crew/IMG_3213.png' },
  { name: 'Aneesh M', role: 'Business Lead', lead: true, photo: '/images/meet-our-crew/ANEESH_PHOTO.jpg' },
  { name: 'Anshul B', role: 'Mechanical Lead', lead: true, photo: '/images/meet-our-crew/Anshul-Tuff.jpg' },
  { name: 'William P', role: 'Team Member', photo: '/images/meet-our-crew/59446.jpg' },
  { name: 'Edison C', role: 'Team Member', photo: '/images/meet-our-crew/Edison_Picture.jpg' },
  { name: 'Martin W', role: 'Team Member', photo: '/images/meet-our-crew/IMG_4351.PNG.png' },
  { name: 'Advik S', role: 'Team Member', photo: '/images/meet-our-crew/48061.jpg' },
  { name: 'Mustafa C', role: 'Team Member', photo: '/images/meet-our-crew/image.png' },
];

const MAKE_WEBHOOK_URL = 'https://hook.us2.make.com/rl67x7cuorapmp6frfejmuuseoqtzend';

// Update these values when your fundraising changes
const GOAL = 3647;
const RAISED = 1215;
const INITIATIVE = 'We are kicking off our first sponsor drive and preparing for our rookie season. More updates coming soon.';

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [contactSent, setContactSent] = useState(false);
  const [contactError, setContactError] = useState('');
  const [contactSending, setContactSending] = useState(false);

  const progress = Math.min(100, Math.round((RAISED / Math.max(GOAL, 1)) * 100));
  const needed = Math.max(GOAL - RAISED, 0);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  const handleContact = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setContactSent(false);
    setContactError('');

    if (!MAKE_WEBHOOK_URL) {
      setContactError('The sponsor form is not connected yet. Add your Make.com webhook URL in the site settings.');
      return;
    }

    const form = event.currentTarget;
    const formData = new FormData(form);
    setContactSending(true);

    try {
      const response = await fetch(MAKE_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.get('name'),
          company: formData.get('company'),
          email: formData.get('email'),
          message: formData.get('message'),
        }),
      });

      if (!response.ok) {
        throw new Error('Webhook request failed');
      }

      setContactSent(true);
      form.reset();
    } catch {
      setContactError('We could not send your message right now. Please try again or email us directly.');
    } finally {
      setContactSending(false);
    }
  };

  return (
    <div className="site-shell">
      <header className="site-header">
        <div className="container header-inner">
          <button className="brand" onClick={() => scrollTo('top')} aria-label="Back to top">
            <span className="brand-mark"><img src="/images/image.png" alt="Pitvipers snake logo" /></span>
            <span><strong>PITVIPERS</strong><small>FTC TEAM 38538</small></span>
          </button>
          <nav className={menuOpen ? 'desktop-nav is-open' : 'desktop-nav'} aria-label="Main navigation">
            <button onClick={() => scrollTo('mission')}>Mission</button>
            <button onClick={() => scrollTo('team')}>Team</button>
            <button onClick={() => scrollTo('progress')}>Progress</button>
            <button onClick={() => scrollTo('spool')}>3D Printing</button>
            <button onClick={() => scrollTo('contact')}>Contact</button>
          </nav>
          <button className="header-cta" onClick={() => scrollTo('join')}>Join the team <ArrowUpRight size={16} /></button>
          <button className="menu-toggle" onClick={() => setMenuOpen((open) => !open)} aria-label="Toggle menu">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <main id="top">
        <section className="hero section-grid">
          <div className="hero-glow" />
          <div className="container hero-layout">
            <div className="hero-copy">
              <div className="eyebrow"><span className="pulse-dot" /> Rookie season · 2026–27</div>
              <h1>Built to <em>learn.</em><br />Driven to <em>compete.</em></h1>
              <p className="hero-lede">We are Pitvipers — a student-run FTC team turning curiosity into machines, ideas into impact, and every challenge into our next advantage.</p>
              <div className="hero-actions">
                <button className="button button-primary" onClick={() => scrollTo('progress')}>Support our team <ArrowUpRight size={17} /></button>
                <button className="button button-ghost" onClick={() => scrollTo('join')}>Join Pitvipers <MoveRight size={17} /></button>
              </div>
              <div className="hero-proof"><span><Trophy size={18} /> Future competitors</span><span><Users size={18} /> One team, every role</span></div>
            </div>
            <div className="hero-art" aria-label="Pitvipers logo">
              <div className="orbit orbit-one" /><div className="orbit orbit-two" />
              <div className="hero-card">
                <div className="card-label"><Radio size={14} /> System online</div>
                <img src="/images/image.png" alt="Pitvipers illustrated snake logo" />
                <div className="hero-card-footer"><span>SEASON 26–27</span><span>V 01 / 00</span></div>
              </div>
              <div className="floating-tag tag-top">ENGINEER<br /><strong>THE UNEXPECTED</strong></div>
              <div className="floating-tag tag-bottom">38538 <span>///</span> PITVIPERS</div>
            </div>
          </div>
          <button className="scroll-cue" onClick={() => scrollTo('mission')} aria-label="Scroll to mission"><ChevronDown size={18} /></button>
        </section>

        <section className="intro-strip"><div className="container intro-inner"><span>FIRST Tech Challenge</span><i>///</i><p>A global robotics competition where students design, build, and program robots to solve complex engineering challenges.</p><span className="strip-arrow"><ArrowUpRight size={18} /></span></div></section>

        <section className="mission section-pad" id="mission">
          <div className="container two-column">
            <div className="section-kicker"><span>01</span><span>Why we exist</span></div>
            <div className="mission-content"><h2>More than a robot.<br /><em>A launchpad.</em></h2><p className="lead-paragraph">Too often, younger students join a team and watch from the sidelines. Pitvipers was founded to change that.</p><p>We are building an application-based team where commitment, curiosity, and effort matter most. Every member gets the chance to own real responsibility, from engineering and software to strategy and business.</p><div className="mission-points"><div><strong>01</strong><span>Real responsibility<br /><small>Learn by owning the work.</small></span></div><div><strong>02</strong><span>Competitive by design<br /><small>Grow fast. Aim high.</small></span></div><div><strong>03</strong><span>Built for everyone<br /><small>Every role moves us forward.</small></span></div></div></div>
          </div>
        </section>

        <section className="team-section section-pad" id="team">
          <div className="container"><div className="section-heading"><div><div className="section-kicker"><span>02</span><span>The humans behind the machine</span></div><h2>Meet the <em>Crew.</em></h2></div><p>Different strengths. Shared standards. One team that refuses to stay still.</p></div><div className="roster-grid">{roster.map((member, index) => <article className={`member-card ${member.lead ? 'lead-card' : ''}`} key={`${member.name}-${index}`}><div className="member-photo"><img src={member.photo} alt={member.name} /><div className="member-index">0{index + 1}</div></div><div className="member-info"><h3>{member.name}</h3><p>{member.role}</p></div></article>)}</div></div>
        </section>

        <section className="progress-section section-pad" id="progress"><div className="container progress-layout"><div><div className="section-kicker"><span>03</span><span>Help us get there</span></div><h2>Fuel the <em>future.</em></h2><p className="progress-copy">A rookie team needs tools, materials, travel, and a whole lot of determination. Your support puts real opportunities in the hands of the next generation of builders.</p><div className="support-links"><button className="text-link" onClick={() => scrollTo('contact')}>Become a sponsor <ArrowUpRight size={16} /></button><a className="text-link" href="https://brookfield-spool-web-ua0j.bolt.host/#about" target="_blank" rel="noreferrer">Shop team-made 3D printed fidgets <ArrowUpRight size={16} /></a></div></div><div className="progress-card"><div className="progress-top"><span>Season goal</span><strong>{progress}%</strong></div><div className="progress-track"><div style={{ width: `${progress}%` }} /></div><div className="progress-numbers"><div><small>Raised</small><strong>${RAISED.toLocaleString()}</strong></div><div><small>Still needed</small><strong>${needed.toLocaleString()}</strong></div><div><small>Goal</small><strong>${GOAL.toLocaleString()}</strong></div></div><div className="initiative-preview"><Sparkles size={15} /><span>{INITIATIVE}</span></div></div></div></section>

        <section className="spool-section section-pad" id="spool"><div className="container spool-layout"><div><div className="section-kicker"><span>04</span><span>Student-run studio</span></div><h2>The Brookfield<br /><em>Spool.</em></h2><p className="spool-copy">The Brookfield Spool is our student-run 3D printing studio, operated by members of our FTC robotics team. We design and manufacture custom fidgets, organizers, accessories, and practical gadgets using high-quality materials and precise printing techniques.</p><p className="spool-copy">All proceeds directly support our robotics team — helping us purchase parts, tools, and competition supplies.</p><div className="spool-features"><div className="spool-feature"><Printer size={20} /><span><strong>Custom designs</strong>Fidgets, organizers & accessories</span></div><div className="spool-feature"><Printer size={20} /><span><strong>Precision printing</strong>High-quality materials, clean results</span></div><div className="spool-feature"><Printer size={20} /><span><strong>Student built</strong>Designed & made by team members</span></div><div className="spool-feature"><Printer size={20} /><span><strong>Supports the team</strong>100% of proceeds fund robotics</span></div></div><a className="button button-primary" href="https://brookfield-spool-web-ua0j.bolt.host/#about" target="_blank" rel="noreferrer">Visit the Brookfield Spool <ArrowUpRight size={17} /></a><div className="spool-note"><Sparkles size={14} /> Every purchase supports FTC Team 38538</div></div><div className="spool-art"><div className="spool-card"><div className="spool-card-label"><Printer size={14} /> Studio online</div><img src="https://images.pexels.com/photos/33977820/pexels-photo-33977820.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="3D printer creating a colorful object" /><div className="spool-card-footer"><span>BROOKFIELD SPOOL</span><span>EST. 2026</span></div></div></div></div></section>

        <section className="contact-section section-pad" id="contact"><div className="container contact-layout"><div><div className="section-kicker"><span>05</span><span>Make an impact</span></div><h2>Let’s build<br /><em>what’s next.</em></h2><p>Whether you want to sponsor our season, mentor a student, or simply learn more, we would love to hear from you.</p><div className="contact-detail"><Mail size={18} /><span>pitvipersftc@gmail.com<br /><small>We’ll get back to you soon.</small></span></div></div><form className="contact-form" onSubmit={handleContact}><div className="form-row"><label>Name<input required name="name" placeholder="Your name" /></label><label>Company<input name="company" placeholder="Your company" /></label></div><label>Email<input required type="email" name="email" placeholder="you@company.com" /></label><label>Message<textarea required name="message" placeholder="How can we work together?" rows={4} /></label><button className="button button-primary" type="submit" disabled={contactSending}>{contactSending ? 'Sending…' : 'Send message'} {!contactSending && <Send size={16} />}</button>{contactSent && <p className="success-message">Thanks — your message was sent. We’ll be in touch.</p>}{contactError && <p className="error-message">{contactError}</p>}</form></div></section>

        <section className="join-section section-pad" id="join"><div className="container join-card"><div><div className="section-kicker"><span>06</span><span>Ready to get involved?</span></div><h2>Find your<br /><em>place here.</em></h2><p>Join a team where you can learn loudly, build boldly, and help shape something from the ground up.</p></div><div className="form-placeholder"><div className="placeholder-top"><span>APPLICATION FORM</span><span>GOOGLE FORM PLACEHOLDER</span></div><div className="placeholder-lines"><span /><span /><span /><span /></div><a className="button button-light" href="https://docs.google.com/forms/d/e/1FAIpQLSeB9lbyTSZP7CuZPsruyKbHTbWGq4rxOiQU_4h3UXFlJRymuA/viewform?usp=publish-editor" target="_blank" rel="noreferrer">Open registration <ArrowUpRight size={16} /></a><small>Applications are open for the 2026–27 season.</small></div></div></section>
      </main>

      <footer className="site-footer"><div className="container footer-top"><div className="footer-brand"><span className="brand-mark"><img src="/images/image.png" alt="Pitvipers logo" /></span><div><strong>PITVIPERS</strong><small>FTC TEAM 38538</small></div></div><div className="footer-links"><button onClick={() => scrollTo('mission')}>Mission</button><button onClick={() => scrollTo('team')}>Team</button><button onClick={() => scrollTo('contact')}>Contact</button></div><div className="socials"><a href="#instagram" aria-label="Instagram"><Instagram size={18} /></a><a href="#youtube" aria-label="Youtube"><Youtube size={18} /></a><a href="#linkedin" aria-label="LinkedIn"><Linkedin size={18} /></a></div></div><div className="container footer-bottom"><span>© 2026 Pitvipers Robotics. All systems nominal.</span><span>FIRST® and FIRST Tech Challenge are registered trademarks of FIRST®. Pitvipers is an independent student-run team.</span></div></footer>
    </div>
  );
}

export default App;
